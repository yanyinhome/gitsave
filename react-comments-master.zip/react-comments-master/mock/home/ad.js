module.exports = [
    {
        title: '暑假5折',
        img: '../resource/imgs/ad/ad1.png',
        link: 'https://www.baidu.com/'
    },
    {
        title: '特价出国',
        img: '../resource/imgs/ad/ad2.png',
        link: 'https://www.baidu.com/'
    },
    {
        title: '亮亮车',
        img: '../resource/imgs/ad/ad3.png',
        link: 'https://www.baidu.com/'
    },
    {
        title: '学钢琴',
        img: '../resource/imgs/ad/ad4.png',
        link: 'https://www.baidu.com/'
    },
    {
        title: '电影',
        img: '../resource/imgs/ad/ad5.png',
        link: 'https://www.baidu.com/'
    },
    {
        title: '旅游热线',
        img: '../resource/imgs/ad/ad6.png',
        link: 'https://www.baidu.com/'
    }
]