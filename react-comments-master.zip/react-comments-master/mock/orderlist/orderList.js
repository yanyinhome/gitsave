module.exports = [
    {
        id: Date.now(),
        img: 'http://images2015.cnblogs.com/blog/138012/201610/138012-20161016201638030-473660627.png',
        title: '汉堡大王',
        count: 3,
        price: '167',
        commentState: 0
    },
    {
        id: Date.now(),
        img: 'http://images2015.cnblogs.com/blog/138012/201610/138012-20161016201708124-1116595594.png',
        title: '麻辣香锅',
        count: 1,
        price: '188',
        commentState: 0
    },
    {
        id: Date.now(),
        img: 'http://images2015.cnblogs.com/blog/138012/201610/138012-20161016201645858-1342445625.png',
        title: '好吃自出餐',
        count: 2,
        price: '110',
        commentState: 2
    }
]