export demo1 from './reducer/demo1.js';//demo1
export demo2 from './reducer/demo2.js';//demo2
