import SI from '../../setInput.js';
const demo1 = SI('demo1',{title: 'demo1'});
export default demo1;
