import SD from '../../setData.js';
const demo2 = SD('demo2', { title: 'demo2'}); //demo2
export default demo2;
