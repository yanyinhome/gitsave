import SD from './setData.js';
const home = SD('home', { title: '首页'}); //首页
export default home;
