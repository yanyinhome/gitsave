/**
 * Created by Administrator on 2017/5/15.
 */
export const RECEIVE_PRODUCTS = 'RECEIVE_PRODUCTS'
export const ADD_PRODUCT = 'ADD_PRODUCT'
export const ADD_COUNT = 'ADD_COUNT'
export const DEL_PRODUCT = 'DEL_PRODUCT'
export const DEC_PRODUCT = 'DEC_PRODUCT'
export const DEL_COUNT = 'DEL_COUNT'
export const CLEAR_PRODUCT = 'CLEAR_PRODUCT'
export const ADD_HISTORY = 'ADD_HISTORY'

